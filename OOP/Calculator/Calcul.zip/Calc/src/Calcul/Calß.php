<?php

namespace Calcul;

class Calс implements CalculatorInterface
{
    use Mull, Sum;

  
}
