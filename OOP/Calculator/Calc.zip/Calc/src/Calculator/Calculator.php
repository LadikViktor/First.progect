<?php

namespace Calculator;

class Calculator implements CalculatorInterface
{
    use Mull, Sum;

}
